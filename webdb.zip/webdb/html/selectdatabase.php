<div id="databases" style="display: none;" class="window-box">
    <div class="window">
        <div class="title">选择数据库

            <a href="javascript:choicewindow()" class="iconfont window-title-btn">&#xe69f;</a><!--选择窗口-->
            <a href="#login" class="iconfont window-title-btn">&#xe627;</a> <!--连接-->
        </div>
        <div style="height: 100%;box-sizing:border-box;">
            <ul id="databasesList" style="height: 100%;box-sizing:border-box;overflow: scroll;">
            </ul>
        </div>
    </div>
</div>
