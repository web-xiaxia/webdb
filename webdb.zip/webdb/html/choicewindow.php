<div id="choice-window" style="display: none;height: 100%; max-width: 800px; margin: 0 auto; overflow: hidden;">

    <ul id="choice-window-window-list">

    </ul>
    <div id="choice-window-bottom" style="">
        <div class="iconfont" onclick="choicewindownew()" style=" line-height: 30px;font-size: 25px;">&#xe602;</div>
    </div>
</div>
