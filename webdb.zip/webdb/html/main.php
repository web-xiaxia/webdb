<div id="loding" style="display: none;position: absolute;width: 100%;height: 100%;">
    <div id="lodingbg"></div>
    <div id="lodingcontent">
        <img src="/webdb/img/loding.jpg" width="20" height="20">
    </div>
    <div id="lodingcancel">
        <div onclick="closeLoding()">x</div>
    </div>
</div>