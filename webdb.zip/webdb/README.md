## 项目介绍

手机网页版(h5)mysql查看工具

## 运行

```
docker run -d --restart=always -p 8984:80   webxiaxia/webdb:0.0.77
http://127.0.0.1:8984/webdb/
```

## 截图

<table>
<tr>
<td><img src="https://raw.githubusercontent.com/web-xiaxia/webdb/master/img/1.jpg" /></td>
<td><img src="https://raw.githubusercontent.com/web-xiaxia/webdb/master/img/2.jpg" /></td>
<td><img src="https://raw.githubusercontent.com/web-xiaxia/webdb/master/img/3.jpg" /></td>
<td><img src="https://raw.githubusercontent.com/web-xiaxia/webdb/master/img/4.jpg" /></td>
</tr>
<tr>
<td><img src="https://raw.githubusercontent.com/web-xiaxia/webdb/master/img/5.jpg" /></td>
<td><img src="https://raw.githubusercontent.com/web-xiaxia/webdb/master/img/6.jpg" /></td>
<td><img src="https://raw.githubusercontent.com/web-xiaxia/webdb/master/img/7.jpg" /></td>
<td></td>
</tr>
</table>