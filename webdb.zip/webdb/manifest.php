{
"orientation": "portrait",
"background_color": "#ffffff",
"theme_color": "#ffffff",
"description": "mysql",
"display": "standalone",
"icons": [
{
"src": "/webdb/favicon.ico"
}
],
"name": "Mysql",
"short_name": "Mysql",
"start_url": "/webdb/?startId=<?php echo md5(uniqid(mt_rand(), true)) ?>"
}
